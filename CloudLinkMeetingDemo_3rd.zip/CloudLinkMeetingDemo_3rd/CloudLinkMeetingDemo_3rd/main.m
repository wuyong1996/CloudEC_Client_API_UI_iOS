//
//  main.m
//  CloudLinkMeetingDemo_3rd
//
//  Created by cloudlink on 2019/4/3.
//  Copyright © 2019年 cloudlink. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
