//
//  CreateConfTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by zhangjianfang on 2019/3/13.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface CreateConfTestCaseViewController : CLMDemoViewController
@property (nonatomic, assign) BOOL withParticipants;//是否带有与会者
@end
