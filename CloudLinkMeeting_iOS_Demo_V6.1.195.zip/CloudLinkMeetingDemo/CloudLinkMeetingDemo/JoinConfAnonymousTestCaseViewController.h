//
//  JoinConfAnonymousTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/6/27.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface JoinConfAnonymousTestCaseViewController : CLMDemoViewController

@end
