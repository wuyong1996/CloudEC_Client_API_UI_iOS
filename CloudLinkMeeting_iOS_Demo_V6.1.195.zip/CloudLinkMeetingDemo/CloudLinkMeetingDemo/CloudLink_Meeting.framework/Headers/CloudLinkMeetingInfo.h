//
//  CloudLinkMeetingInfo.h
//  CloudLink Meeting
//
//  Created by zhangjianfang on 2019/2/25.
//

#import <Foundation/Foundation.h>

extern NSString* const clmErrorDomain;
extern NSString* const clmUninitErrorDescription;
extern NSString* const clmActionInProcessDescription;

//clm接口结果枚举
typedef NS_ENUM(NSInteger, CLM_RESULT) {
    CLM_RESULT_IN_PROCESS = -2,   //当前请求在进行中
    CLM_RESULT_FAILED = -1,
    CLM_RESULT_SUCCESS = 0,
    
};


//会议类型枚举
typedef NS_ENUM(NSInteger, CONF_MEDIATYPE) {
    CONF_MEDIA_FLAG_VOICE_DATA = 17,   //语音加数据
    CONF_MEDIA_FLAG_VIDEO_DATA = 19,    //视频加数据
};

@interface clmInitParam : NSObject
@property (nonatomic, copy) NSString *config;   //配置参数内容，详情参见示例各字段含义
@property (nonatomic, copy) NSString *appId;    //应用的appId，必须填写（请填写开发公司名称）
@end

@interface clmLoginParam : NSObject
@property (nonatomic, copy) NSString *serverAddress;   //登录地址
@property (nonatomic, assign) NSInteger serverPort;    //登录端口
@property (nonatomic, copy) NSString *account;         //登录账号(账号密码登录方式)
@property (nonatomic, copy) NSString *password;        //登录密码(账号密码登录方式)
@property (nonatomic, copy) NSString *domain;          //企业域名(sso 登录方式)
@property (nonatomic, copy) NSString *userTicket;      // user ticket(sso 登录方式)
@end

@interface clmCallParam : NSObject
@property (nonatomic, copy) NSString *number;    //被叫号码(账号、号码二选一)
@property (nonatomic, copy) NSString *account;   //被叫账号(账号、号码二选一)
@property (nonatomic, assign) BOOL isVideo;      //是否为视频呼叫

@end

@interface clmCreateMeetingParam : NSObject
@property (nonatomic, copy) NSString *meetingSubject;       //会议主题
@property (nonatomic, assign) CONF_MEDIATYPE meetingType;   //会议类型
@property (nonatomic, assign) BOOL needAccessCode;          //会议是否需要接入码
@end

@interface clmJoinMeetingParam : NSObject
@property (nonatomic, copy) NSString *meetingID;  //会议ID
@property (nonatomic, copy) NSString *accessCode; //会议接入码
@end

@interface clmJoinMeetingAnonymousParam : NSObject
@property (nonatomic, copy) NSString *serverAddress;   //匿名入会地址
@property (nonatomic, assign) NSInteger serverPort;    //匿名入会端口
@property (nonatomic, copy) NSString *meetingID;       //匿名入会ID
@property (nonatomic, copy) NSString *accessCode;      //匿名入会接入码(可选)
@property (nonatomic, copy) NSString *nickName;        //匿名入会昵称
@end

@interface clmMeetingParticipantParam : NSObject
@property (nonatomic, copy) NSString *number;    //与会者号码
@property (nonatomic, copy) NSString *name;      //与会者姓名
@end

