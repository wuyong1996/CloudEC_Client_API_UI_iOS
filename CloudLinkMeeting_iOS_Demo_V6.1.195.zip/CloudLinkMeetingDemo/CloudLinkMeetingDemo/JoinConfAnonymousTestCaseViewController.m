//
//  JoinConfAnonymousTestCaseViewController.m
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/6/27.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "JoinConfAnonymousTestCaseViewController.h"
#import <CloudLink_Meeting/CloudLinkMeeting.h>

#define START_Y 80
#define TEXT_FIELD_WIDTH 280
#define TEXT_FIELD_HEIGHT 40
#define FIELD_H_SEP   5

@interface JoinConfAnonymousTestCaseViewController ()
@property (nonatomic, strong) UITextField *serverAddressField;
@property (nonatomic, strong) UITextField *serverPortField;
@property (nonatomic, strong) UITextField *confIdField;
@property (nonatomic, strong) UITextField *accessCodeField;
@property (nonatomic, strong) UITextField *nickNameField;
@property (nonatomic, strong) UIButton *joinClmConfAnonymousBtn;
@end

@implementation JoinConfAnonymousTestCaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.serverAddressField];
    [self.view addSubview:self.serverPortField];
    [self.view addSubview:self.confIdField];
    [self.view addSubview:self.accessCodeField];
    [self.view addSubview:self.nickNameField];
    [self.view addSubview:self.joinClmConfAnonymousBtn];
}

- (UITextField *)serverAddressField {
    if (nil == _serverAddressField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _serverAddressField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                     START_Y,
                                                                     TEXT_FIELD_WIDTH,
                                                                     TEXT_FIELD_HEIGHT)];
        _serverAddressField.borderStyle = UITextBorderStyleLine;
        _serverAddressField.text = @"cloudec.huaweicloud.com";
        _serverAddressField.placeholder = @"服务器地址";
    }
    return _serverAddressField;
}

- (UITextField *)serverPortField {
    if (nil == _serverPortField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _serverPortField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                     START_Y + FIELD_H_SEP + TEXT_FIELD_HEIGHT,
                                                                     TEXT_FIELD_WIDTH,
                                                                     TEXT_FIELD_HEIGHT)];
        _serverPortField.borderStyle = UITextBorderStyleLine;
        _serverPortField.text = @"8443";
        _serverPortField.placeholder = @"服务器端口";
    }
    return _serverPortField;
}

- (UITextField *)confIdField {
    if (nil == _confIdField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _confIdField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                     START_Y + 2 * FIELD_H_SEP + 2 * TEXT_FIELD_HEIGHT,
                                                                     TEXT_FIELD_WIDTH,
                                                                     TEXT_FIELD_HEIGHT)];
        _confIdField.borderStyle = UITextBorderStyleLine;
        _confIdField.text = @"";
        _confIdField.placeholder = @"会议ID";
    }
    return _confIdField;
}

- (UITextField *)accessCodeField {
    if (nil == _accessCodeField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _accessCodeField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                       START_Y + 3 * FIELD_H_SEP + 3 * TEXT_FIELD_HEIGHT,
                                                                       TEXT_FIELD_WIDTH,
                                                                       TEXT_FIELD_HEIGHT)];
        _accessCodeField.borderStyle = UITextBorderStyleLine;
        _accessCodeField.text = @"";
        _accessCodeField.placeholder = @"会议接入码(可选)";
    }
    return _accessCodeField;
}

- (UITextField *)nickNameField {
    if (nil == _nickNameField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _nickNameField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                         START_Y + 4 * FIELD_H_SEP + 4 * TEXT_FIELD_HEIGHT,
                                                                         TEXT_FIELD_WIDTH,
                                                                         TEXT_FIELD_HEIGHT)];
        _nickNameField.borderStyle = UITextBorderStyleLine;
        _nickNameField.text = @"";
        _nickNameField.placeholder = @"昵称";
    }
    return _nickNameField;
}

- (UIButton *)joinClmConfAnonymousBtn {
    if (nil == _joinClmConfAnonymousBtn) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _joinClmConfAnonymousBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _joinClmConfAnonymousBtn.backgroundColor = [UIColor redColor];
        [_joinClmConfAnonymousBtn setTitle:@"clm_joinConfAnonymous" forState:UIControlStateNormal];
        _joinClmConfAnonymousBtn.frame = CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                           START_Y + 5 * FIELD_H_SEP + 5 * TEXT_FIELD_HEIGHT,
                                           TEXT_FIELD_WIDTH,
                                           TEXT_FIELD_HEIGHT);
        [_joinClmConfAnonymousBtn addTarget:self action:@selector(joinClmConfAnonymous:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _joinClmConfAnonymousBtn;
}

- (void)joinClmConfAnonymous:(id)sender {
    [self.view endEditing:YES];
    CloudLinkMeeting *clm = [CloudLinkMeeting sharedInstance];
    clmJoinMeetingAnonymousParam *param = [[clmJoinMeetingAnonymousParam alloc] init];
    param.serverAddress = self.serverAddressField.text;
    param.serverPort = [self.serverPortField.text integerValue];
    param.meetingID = self.confIdField.text;
    param.accessCode = self.accessCodeField.text;
    param.nickName = self.nickNameField.text;
    UIActivityIndicatorView *activeView = [[UIActivityIndicatorView alloc] initWithFrame:self.view.bounds];
    activeView.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
    activeView.color = [UIColor darkGrayColor];
    [self.view addSubview:activeView];
    [activeView startAnimating];
    [clm clm_joinMeetingAnonymous:param completionBlock:^(NSError *error) {
        NSLog(@"clm join meeting anonymous, result is:%@", error);
        dispatch_async(dispatch_get_main_queue(), ^{
            [activeView stopAnimating];
            [activeView removeFromSuperview];
            if (error) {
                NSString *message = (nil == error ? @"success" : [NSString stringWithFormat:@"failed:%@", error]);
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"clm_joinConfAnonymous result" message:message preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alert addAction:action];
                [self.navigationController presentViewController:alert animated:YES completion:nil];
            }
        });
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
