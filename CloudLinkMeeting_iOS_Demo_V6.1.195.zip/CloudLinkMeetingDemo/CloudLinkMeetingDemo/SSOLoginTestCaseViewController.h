//
//  SSOLoginTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by 融合软终端02 on 2019/5/31.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface SSOLoginTestCaseViewController : CLMDemoViewController

@end
