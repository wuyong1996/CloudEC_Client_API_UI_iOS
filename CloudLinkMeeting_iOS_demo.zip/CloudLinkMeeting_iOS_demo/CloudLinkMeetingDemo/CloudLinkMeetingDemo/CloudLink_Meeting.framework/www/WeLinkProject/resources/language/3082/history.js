module.exports={
    "TARGET_TO_CONTEXT":"Ver contexto",
    "HISTORY":"Historial"
}