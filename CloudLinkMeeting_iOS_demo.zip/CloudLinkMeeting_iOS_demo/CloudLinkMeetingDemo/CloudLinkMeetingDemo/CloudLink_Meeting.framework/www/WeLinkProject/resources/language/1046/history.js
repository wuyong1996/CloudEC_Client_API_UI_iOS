module.exports={
    "TARGET_TO_CONTEXT":"Exibir contexto",
    "HISTORY":"Histórico"
}