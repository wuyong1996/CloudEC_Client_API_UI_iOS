//
//  SSOLoginTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by 融合软终端02 on 2019/5/31.
//  Copyright © 2019 huawei. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SSOLoginTestCaseViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
