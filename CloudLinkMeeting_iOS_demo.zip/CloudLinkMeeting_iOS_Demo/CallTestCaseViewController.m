//
//  CallTestCaseViewController.m
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/5/29.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CallTestCaseViewController.h"
#import <CloudLink_Meeting/CloudLinkMeeting.h>

#define START_Y 80
#define LBL_WIDTH  60
#define LBL_HEIGHT 40
#define TEXT_FIELD_WIDTH 200
#define TEXT_FIELD_HEIGHT 40
#define FIELD_H_SEP   10

@interface CallTestCaseViewController ()
@property (nonatomic, strong) UITextField *callNumberTextField;
@property (nonatomic, strong) UITextField *accountTextField;
@property (nonatomic, strong) UISwitch *isVideoSwitch;
@property (nonatomic, strong) UILabel *isVideoLbl;
@property (nonatomic, strong) UIButton *callBtn;
@end

@implementation CallTestCaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.callNumberTextField];
    [self.view addSubview:self.accountTextField];
    [self.view addSubview:self.isVideoLbl];
    [self.view addSubview:self.isVideoSwitch];
    [self.view addSubview:self.callBtn];
}

- (UITextField *)callNumberTextField {
    if (nil == _callNumberTextField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _callNumberTextField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                          START_Y,
                                                                          TEXT_FIELD_WIDTH,
                                                                          TEXT_FIELD_HEIGHT)];
        _callNumberTextField.borderStyle = UITextBorderStyleLine;
        _callNumberTextField.placeholder = @"呼叫号码";
        _callNumberTextField.text = @"";
    }
    return _callNumberTextField;
}

- (UITextField *)accountTextField {
    if (nil == _accountTextField) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _accountTextField = [[UITextField alloc] initWithFrame:CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                                                             START_Y + FIELD_H_SEP + TEXT_FIELD_HEIGHT,
                                                                             TEXT_FIELD_WIDTH,
                                                                             TEXT_FIELD_HEIGHT)];
        _accountTextField.borderStyle = UITextBorderStyleLine;
        _accountTextField.placeholder = @"账号";
        _accountTextField.text = @"";
    }
    return _accountTextField;
}

- (UILabel *)isVideoLbl {
    if (nil == _isVideoLbl) {
        _isVideoLbl = [[UILabel alloc] initWithFrame:CGRectMake(0,
                                                                  START_Y + 2 * FIELD_H_SEP + 2 * TEXT_FIELD_HEIGHT,
                                                                  2 * LBL_WIDTH,
                                                                  LBL_HEIGHT)];
        _isVideoLbl.text = @"视频呼叫";
    }
    return _isVideoLbl;
}

- (UISwitch *)isVideoSwitch {
    if (nil == _isVideoSwitch) {
        _isVideoSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(2 * LBL_WIDTH,
                                                                      START_Y + 2 * FIELD_H_SEP + 2 * TEXT_FIELD_HEIGHT,
                                                                      TEXT_FIELD_WIDTH,
                                                                      TEXT_FIELD_HEIGHT)];
    }
    return _isVideoSwitch;
}

- (UIButton *)callBtn {
    if(nil == _callBtn) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;

        _callBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _callBtn.backgroundColor = [UIColor redColor];
        [_callBtn setTitle:@"clm_call" forState:UIControlStateNormal];
        _callBtn.frame = CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                          START_Y + 3 * FIELD_H_SEP + 3 * TEXT_FIELD_HEIGHT,
                                          TEXT_FIELD_WIDTH,
                                          TEXT_FIELD_HEIGHT);
        [_callBtn addTarget:self action:@selector(callBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _callBtn;
}

- (void)callBtnClick:(id)sender {
    clmCallParam *param = [[clmCallParam alloc] init];
    param.number = self.callNumberTextField.text;
    param.account = self.accountTextField.text;
    param.isVideo = self.isVideoSwitch.isOn;
    [[CloudLinkMeeting sharedInstance] clm_call:param completionBlock:^(NSError *error) {
        NSLog(@"create clm call ,error is:%@", error);
        if (error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSString *message = (nil == error ? @"success" : [NSString stringWithFormat:@"failed:%@", error]);
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"clm_call result" message:message preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alert addAction:action];
                [self.navigationController presentViewController:alert animated:YES completion:nil];
            });
        }
    }];
}

@end
