//
//  SampleHandler.h
//  CloudLinkMeetingScreenShareDemo
//
//  Created by cloudlink on 2019/4/20.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
