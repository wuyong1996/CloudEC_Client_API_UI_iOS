//
//  HWMConfDetail.h
//  HWMConf
//
//  Created by 融合软终端02 on 2020/1/6.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMConfSdkDefine.h"
NS_ASSUME_NONNULL_BEGIN

@interface HWMConfDetail : NSObject

@property (nonatomic, assign) NSUInteger size; // 会议方数
@property (nonatomic, copy) NSString *confId; // 会议id
@property (nonatomic, copy) NSString *confSubject; // 会议主题
@property (nonatomic, copy) NSString *accessNumber; // 会议接入码
@property (nonatomic, copy) NSString *chairmanPwd; // 主席密码
@property (nonatomic, copy) NSString *generalPwd; // 来宾密码
@property (nonatomic, copy) NSString *startTime; // 会议开始时间
@property (nonatomic, copy) NSString *endTime; // 会议结束时间
@property (nonatomic, assign) ConfMediaType mediaType; // 媒体类型，取值参考CONFCTRL_E_CONF_MEDIATYPE_FLAG，可进行"|"操作
@property (nonatomic, assign) ConfStatusType confState; // 会议状态
@property (nonatomic, copy) NSString *scheduserNumber; // 预订者账号
@property (nonatomic, copy) NSString *scheduserName; // 预订者姓名
@property (nonatomic, copy) NSString *token; // 会控token 仅入驻式融合会议有效
@property (nonatomic, copy) NSString *chairJoinUri; // 主持人加入会议uri链接
@property (nonatomic, copy) NSString *guestJoinUri; // 普通与会者加入会议uri链接
@property (nonatomic, copy) NSString *chairmanUUID; // 主席加入数据会议使用的uuid
@property (nonatomic, copy) NSString *guestUUID; // 普通与会者加入数据会议使用的uuid
@property (nonatomic, copy) NSString *scheduleUUID; // 会议预约者的uuid
@property (nonatomic, copy) NSString *vmrId; // VMR会议ID
@property (nonatomic, assign) NSUInteger recordType; // 可选，录制类型：0.禁用；1.直播；2.录播；3.直播+录播
@property (nonatomic, assign) BOOL recordAuxStream; // 可选，会议是否录制辅流：0.不录制；1.录制
@property (nonatomic, assign) BOOL vmrFlag; // 可选，是否是VMR会议
@property (nonatomic, assign) BOOL scheduleVmr; // 可选，是否是VMR预约记录：0.普通会议记录；1.VMR预约记录
@property (nonatomic, assign) BOOL enableConfSignIn; // 可选，会议是否支持签到: 0. 不签到; 1. 签到
@property (nonatomic, assign) NSUInteger signInTimeBeforeConf; // 可选，会议提前多久签到，单位: 分钟. 范围同SMC: 1~360
@property (nonatomic, copy) NSString *joinAdvanceTime; // 可选，可提前入会的时间

@property (nonatomic, assign) BOOL isGuestFreePwd; // 是否来宾免密
@property (nonatomic, assign) BOOL isSendNotify;//是否发送邮件通知
@property (nonatomic, assign) BOOL isSendSms; //是否发送短信通知
@property (nonatomic, assign) HWMCallInRestrictionType callInRestriction; //呼入限制


@property (nonatomic, copy) NSString *vmrModifyId; // 每一个用VMRId创建的会议的标识，编辑会议时用
@property (nonatomic, copy) NSString *shareTime; // 会议时间，分享会议场景使用

- (NSString *)startDate;

- (BOOL)joinEnable;

- (NSString *)startShortTime;

- (NSString *)endShortTime;
- (BOOL)isVideo;

- (BOOL)isRecord;
- (void)setIsRecord:(BOOL)isRecord;

@end

NS_ASSUME_NONNULL_END
