//
//  HWMSdk.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMOpenSDKConfig.h"
#import "HWMOpenApi.h"
#import "HWMPrivateApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMSdk : NSObject

/// 初始化SDK
/// @param config 配置信息
+ (BOOL)initWithConfig:(HWMOpenSDKConfig *)config;

+ (BOOL)hasInit;

/// get config model
+ (HWMOpenSDKConfig *)getSdkConfig;


/// 更新服务器地址和端口
/// @param url login server url
/// @param port login server port

+ (void)setServerConfigWithUrl:(NSString *)url port:(NSInteger)port;


/// 获取api对象
+ (HWMOpenApi *)getOpenApi;

+ (HWMPrivateApi *)getPrivateApi;

/// 设置日志路径
/// config log path
/// @param logPath log path
+ (void)setLogPath:(NSString *)logPath;

/// 切换语言
/// config language 切换语言
/// @param language language
+ (void)setLanguage:(HWMSdkLanguageType)language;


/// 上报sdk crash
/// @param exception crash对象
+ (void)reportCrash:(NSException *)exception;

@end

NS_ASSUME_NONNULL_END
