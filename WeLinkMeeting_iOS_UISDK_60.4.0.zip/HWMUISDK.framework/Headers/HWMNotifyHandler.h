//
//  HWMNotifyHandler.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMSdkDefine.h"
NS_ASSUME_NONNULL_BEGIN

@protocol HWMNotifyHandler <NSObject>
@optional

/// 账号被踢，收到该通知表示账号已经在其他设备登录，如果需要继续操作，需要重新调用登录接口
/// @param result uuid
- (void)onKickedOut:(NSString *)result;

/// 通话状态变更通知
/// @param status 会议状态
- (void)onCallStatusChanged:(HWMSDKCallStatus)status;

/// 会议状态变更通知
/// @param status 会议状态
- (void)onConfStatusChanged:(HWMSDKConfStatus)status;

/// USG Token 刷新通知
- (void)onLoginTokenChanged:(NSString *)token;

/// 登录失败消息通知
- (void)onLoginError:(NSError *)error;

@end

NS_ASSUME_NONNULL_END
