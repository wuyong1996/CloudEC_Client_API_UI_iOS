//
//  HWMConfUIHandler.h
//  HWMConfUI
//
//  Created by 融合软终端02 on 2020/3/11.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMSocialShareModel.h"
#import "HWMConfDetail.h"
#import "HWMShareLinkModel.h"
NS_ASSUME_NONNULL_BEGIN

@protocol HWMSocialShareHandler <NSObject>
@optional

/// 分析会议拦截处理函数，如果实现该协议方法，则会中调用分享功能，会回调到该方法
/// @param confInfo 会议信息
/// @param controller 当前的vc

- (void)shareConf:(HWMConfDetail *)confInfo inCtrl:(UIViewController *)controller;


@end

NS_ASSUME_NONNULL_END
