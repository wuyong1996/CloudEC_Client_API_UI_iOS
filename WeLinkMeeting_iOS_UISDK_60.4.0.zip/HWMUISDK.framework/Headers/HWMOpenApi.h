//
//  HWMOpenApi.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMCreateConfParam.h"
#import "HWMJoinConfParam.h"
#import "HWMStartCallParam.h"
#import "HWMSdkDefine.h"
#import "HWMContactSelectedModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HWMOpenApi : NSObject

/// 登录接口
/// @param account 账号
/// @param password 密码
/// @param callback 结果回调，返回登录用户的UUID
- (void)login:( NSString * _Nonnull )account password:( NSString * _Nonnull )password callback:(_Nonnull HWMSDKLoginCompleteHandler)callback;


/// 创建会议
/// @param param 创会参数
/// @param callback 结果回调
- (void)createConf:(HWMCreateConfParam * _Nonnull)param callback:( _Nonnull HWMSDKCreateConfCompleteHandler)callback;


/// 加入会议
/// @param param 入会参数
/// @param callback 结果回调
- (void)joinConf:(HWMJoinConfParam * _Nonnull)param callback:(_Nonnull HWMSDKCompleteHandler)callback;


/// 发起呼叫
/// @param param 呼叫参数
/// @param callback 结果回调
- (void)startCall:(HWMStartCallParam *_Nonnull)param callback:(_Nonnull HWMSDKCompleteHandler)callback;

/// 登出
/// @param callback 结果回调
- (void)logout:(_Nonnull HWMSDKCompleteHandler)callback;



@end

NS_ASSUME_NONNULL_END
