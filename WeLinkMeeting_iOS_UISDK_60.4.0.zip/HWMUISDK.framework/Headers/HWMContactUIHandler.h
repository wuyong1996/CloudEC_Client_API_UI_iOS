//
//  HWMContactSelectHandler.h
//  Pods
//
//  Created by fuxihua on 2020/3/10.
//

#ifndef HWMContactSelectHandler_h
#define HWMContactSelectHandler_h
#import "HWMContactSelectedModel.h"
#import "HWMConfContactModel.h"

@protocol HWMContactUIHandler <NSObject>
@optional

- (void)openContactSelectPage:(NSArray<NSString *> *)param
completeHander:(void(^)(NSArray<HWMContactSelectedModel *> *result, NSError *error))handler;

- (void)openContactSelectPage:(NSArray<HWMConfContactModel *> *)param
                        scene:(HWMSelectedContactScene)scene
               completeHander:(void(^)(NSArray<HWMContactSelectedModel *> *result, NSError *error))handler;

@end




#endif /* HWMContactSelectHandler_h */
