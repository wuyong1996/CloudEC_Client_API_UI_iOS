//
// Created by 融合软终端02 on 2020-01-10.
// Copyright (c) 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface HWMEnterpriseContact : NSObject
@property (nonatomic, strong) NSString *contactId;
@property (nonatomic, assign) NSInteger statusCode;
@property (nonatomic, strong) NSString *account;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *englishName;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *phone;
@property (nonatomic, strong) NSString *deptName;
@property (nonatomic, strong) NSString *number;
@property (nonatomic, strong) NSString *signature;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *updateTime;
@property (nonatomic, assign) BOOL isHardTerminal;
@property (nonatomic, assign) BOOL hidePhone;
@property (nonatomic, assign) int type;
@property (nonatomic, strong) NSString * contactDescription;
// 计算型属性
@property (nonatomic, strong) NSString * shortPhone;
@property (nonatomic, strong) NSString * officePhone2;
@end
