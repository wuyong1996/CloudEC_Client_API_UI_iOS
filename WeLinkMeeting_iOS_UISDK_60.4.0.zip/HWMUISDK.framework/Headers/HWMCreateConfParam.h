//
//  HWMCreateConfParam.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMConfSdkDefine.h"

typedef NS_ENUM(NSUInteger, HWMConfType) {
    HWMConfTypeAudio, // 音频会议
    HWMConfTypeVideo, // 视频会议
    HWMConfTypeAudioAndData,// 音频数据会议
    HWMConfTypeVideoData// 视频数据会议
};
NS_ASSUME_NONNULL_BEGIN


@interface HWMCreateConfMember : NSObject
// 与会者 名字
@property(nonatomic, strong)NSString *name;

// 与会者号码
@property(nonatomic, strong)NSString *number;

// 用户账号ID
@property(nonatomic, strong)NSString *accoundId;

// 终端类型
@property(nonatomic, assign)HWMClientDeviceType clientType;

@end


@interface HWMCreateConfParam : NSObject

/// 会议主题
@property(nonatomic, strong) NSString *subject;

/// 会议媒体类型 默认语音会议
@property(nonatomic, assign) HWMConfType confType;

/// 会议是否需要设置密码，默认不需要
@property(nonatomic, assign) BOOL needPassword;

/// 成员列表
@property(nonatomic, strong) NSArray <HWMCreateConfMember *> *members;

/// 是否打开摄像头, 默认打开
@property(nonatomic, assign) BOOL isCameraOn;

/// 是否打开麦克风， 默认打开
@property(nonatomic, assign) BOOL isMicOn;


@end

NS_ASSUME_NONNULL_END
