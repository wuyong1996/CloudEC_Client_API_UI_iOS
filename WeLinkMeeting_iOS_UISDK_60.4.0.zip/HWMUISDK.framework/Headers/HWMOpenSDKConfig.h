//
//  HWMOpenSDKConfig.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMNotifyHandler.h"
#import "HWMSharePopHandler.h"
#import "HWMSocialShareHandler.h"
#import "HWMCallUIHandler.h"
#import "HWMContactUIHandler.h"
#import "HWMConfUIHandler.h"

typedef enum : NSUInteger {
    HWMSdkLanguageTypeZH,
    HWMSdkLanguageTypeEN,
    HWMSdkLanguageTypeFR,
} HWMSdkLanguageType;

NS_ASSUME_NONNULL_BEGIN

@interface HWMOpenSDKConfig : NSObject
// require
@property (nonatomic, strong) NSString *appId; // appId
@property (nonatomic, strong) NSString *appGroupIndentifier;

// options
@property (nonatomic, strong , readonly) NSString *sdkVersion; // SDK 版本号，只读
@property (nonatomic, assign) NSInteger platform; //private params，调用方不需要设置
@property (nonatomic, assign) BOOL closeCrashReport; // 默认false
@property (nonatomic, strong, nullable) NSString *serverAddress;
@property (nonatomic, assign) NSUInteger serverPort;
/// 日志路径
@property (nonatomic, copy) NSString *logPath;
/// 语言
@property (nonatomic, assign) HWMSdkLanguageType language;
@property (nonatomic, weak, nullable)id <HWMNotifyHandler> globalHandler;// 可选，全局通知代理
@property (nonatomic, weak, nullable)id <HWMSocialShareHandler> socialShareHandler; // 社交分享代理
@property (nonatomic, weak, nullable)id <HWMCallUIHandler> callingUIHandler; // 通话UI 代理
@property (nonatomic, weak, nullable)id <HWMContactUIHandler> contactUIHandler; // 联系人UI 代理
@property (nonatomic, weak, nullable)id <HWMConfUIHandler> confUIHandler; // 会议UI 代理
@end

NS_ASSUME_NONNULL_END
