//
//  HWMLoginResult.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMLoginResult : NSObject
@property (nonatomic, strong)NSString *uuid;
@end

NS_ASSUME_NONNULL_END
