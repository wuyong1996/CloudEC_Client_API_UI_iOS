//
//  HWMPrivateApi.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/4/9.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMContactSelectedModel.h"
#import "HWMControllerConfig.h"
#import "HWMPrivateNotifyHandler.h"

@class HWMHardTerminalViewParam;
@class HWMLoginInfo;
NS_ASSUME_NONNULL_BEGIN

@interface HWMPrivateApi : NSObject

/// 设置全局导航栏样式
- (void)setGlobalNavigationBarStyle:(HWMNavigationBarStyle *)style;

/// 获取全局导航栏样式
- (HWMNavigationBarStyle *)getGlobalNavigationBarStyle;

/// 显示会议列表界面
/// @param config 导航栏样式配置
- (void)openConfListWitConfig:(HWMControllerConfig *)config animated:(BOOL)animated;

- (void)openSelectedContactWithMembers:(NSArray <NSString *> *)members callback:(void (^)(NSArray <HWMContactSelectedModel *> *result, NSError *error))callback;

- (void)feedbackLogByEMail;

/// 链接入会
- (void)joinConfByLink:(NSString *)siteUrl random:(NSString *)random callback:(void (^)(NSError *error))callback;

/// 显示硬终端入会界面
- (void)openHardTerminalConfListCtrlWithParam:(HWMHardTerminalViewParam *)param;

/// MaxHub扫码配对入会
/// @param pairCode 配对码
- (void)maxhubPairWithPairCode:(NSString *)pairCode callback:(void (^)(NSError *error))callback;

/// 获取登录信息
- (HWMLoginInfo *)getMyInfo;

/// 通过account token登录
- (void)loginWithAccount:(NSString *)account token:(NSString *)token completeHandler:(void (^_Nonnull)(NSError *_Nullable error))handler;

/// 是否存在通话
- (BOOL)isCallExist;

/// 是否为视频通话
- (BOOL)isVideoCall;

/// 是否存在会议
- (BOOL)isConfExist;

/// 是否为视频会议
- (BOOL)isVideoConf;

/// 显示匿名入会界面
- (void)openAnonymousJoinPage:(HWMControllerConfig *)config animated:(BOOL)animated;

/// 设置屏幕共享插件名称（bundle尾缀名称）
- (void)setShareExtensionName:(NSString *)extensionName;

@end

NS_ASSUME_NONNULL_END
