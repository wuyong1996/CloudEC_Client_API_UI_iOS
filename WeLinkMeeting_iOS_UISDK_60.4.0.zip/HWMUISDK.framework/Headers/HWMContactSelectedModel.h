//
//  HWMEnterpriseContactSelectedModel.h
//  Aspects
//
//  Created by fuxihua on 2020/1/20.
//

#import <Foundation/Foundation.h>
#import "HWMEnterpriseDepartmentConstant.h"
#import "HWMEnterpriseContact.h"

@interface HWMContactSelectedModel : NSObject
@property (nonatomic, assign) HWMSelectedContactType contactType;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *number;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *sms; 
@property (nonatomic, copy) NSString *accountId;
@property (nonatomic, assign) int type;
@property (nonatomic, assign) BOOL isHardTerminal;

/**
 *  企业联系人的HWMContactSelectedModel 初始化
 *
 *  @param contact    企业联系人信息
 *  @param number      号码
 */
- (instancetype)initWithContact:(HWMEnterpriseContact *)contact
                         number:(NSString *)number;


/**
 *  HWMContactSelectedModel 初始化
 *
 *  @param name    名称
 *  @param number    号码
 *  @param contactType    联系人类型
 */
- (instancetype)initWithName:(NSString *)name
                      number:(NSString *)number
                 contactType:(HWMSelectedContactType)contactType;
@end


