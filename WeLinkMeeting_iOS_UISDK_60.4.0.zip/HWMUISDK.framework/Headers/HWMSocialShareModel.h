//
//  HWMSocialShareModel.h
//  HWMConfUI
//
//  Created by 融合软终端02 on 2020/3/11.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMSocialShareModel : NSObject
@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *iconName;
@property (nonatomic, copy) void(^clickEvent)(HWMSocialShareModel *);

@end

NS_ASSUME_NONNULL_END
