//
//  HWMSdkDefine.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/31.
//  Copyright © 2020 huawei. All rights reserved.
//

#ifndef HWMSdkDefine_h
#define HWMSdkDefine_h
#import "HWMLoginResult.h"
#import "HWMCreateConfResult.h"

// 通用回调，error为nil表示调用成功，否则调用失败，result 为预留扩展参数，请忽略
typedef void (^HWMSDKCompleteHandler)(NSError *_Nullable error, id _Nullable result);

// 登录回调，error为nil表示调用成功，否则调用失败，result 返回登录用户的信息
typedef void (^HWMSDKLoginCompleteHandler)(NSError *_Nullable error, HWMLoginResult *_Nullable result);

// 创建会议回调，error为nil表示调用成功，否则调用失败，result会议信息
typedef void (^HWMSDKCreateConfCompleteHandler)(NSError *_Nullable error, HWMCreateConfResult *_Nullable result);

/// 呼叫状态
typedef NS_ENUM (NSUInteger, HWMSDKCallStatus) {
    /// 空闲状态 (通话结束)
    HWMSDKCallStatusIdle = 0,
    /// 正在来电
    HWMSDKCallStatusIncoming,
    /// 正在呼出
    HWMSDKCallStatusCallingOut,
    /// 已接通
    HWMSDKCallStatusConnected,
};

/// 会议状态
typedef NS_ENUM (NSUInteger, HWMSDKConfStatus) {
    /// 空闲状态 （会议结束）
    HWMSDKConfStatusIdle = 0,
    /// 正在来电
    HWMSDKConfStatusIncoming,
    /// 正在呼出
    HWMSDKConfStatusCallingOut,
    /// 已接通
    HWMSDKConfStatusConnected,
    /// 正在重呼
    HWMSDKConfStatusRecalling,
};

#endif /* HWMSdkDefine_h */
