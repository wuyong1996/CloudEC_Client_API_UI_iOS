//
//  HWMConfUIHandler.h
//  HWMConfUI
//
//  Created by l00465337 on 2020/4/22.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol HWMConfUIHandler <NSObject>

#pragma mark - DataSource
/// 屏幕共享/白板共享的封面视图，可放水印等。注意不要添加全局手势
- (UIView *)screenShareCoverView;

/// 会中界面即将显示，用于设置旋转等。
- (void)inMeetingViewWillAppear:(UIViewController *)controller;

/// 会中界面即将消失，用于设置旋转等。
- (void)inMeetingViewWillDisappear:(UIViewController *)controller;

@end

NS_ASSUME_NONNULL_END
