//
//  HWMShareLinkModel.h
//  HWMCommonUI
//
//  Created by 融合软终端02 on 2020/4/13.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMShareLinkModel : NSObject
@property (nonatomic, copy) NSString *shareUrl;
@property (nonatomic, copy) NSString *wechatTitle;
@property (nonatomic, copy) NSString *wechatDesc;
@property (nonatomic, copy) NSString *smsDesc;
@property (nonatomic, copy) NSString *emailTitle;
@property (nonatomic, copy) NSString *emailDesc;
@property (nonatomic, copy) NSString *linkCopiedDesc;
@property (nonatomic, copy) NSString *linkCopySuccessDesc;

// 分享下载链接
+ (HWMShareLinkModel *)shareDownloadLinkModel;
// 分享会议
+ (HWMShareLinkModel *)shareConfLinkWithUrl:(NSString *)shareUrl
                                    subject:(NSString *)subject
                                       time:(NSString *)time
                                       host:(NSString *)host
                                     confId:(NSString *)confId
                                   guestPwd:(NSString *)guestPwd;

@end

NS_ASSUME_NONNULL_END
