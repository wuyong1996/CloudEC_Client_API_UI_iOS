//
//  HWMEnterpriseDepartmentConstant.h
//  HWMConf
//
//  Created by fuxihua on 2020/1/19.
//  Copyright © 2020 huawei. All rights reserved.
//

#ifndef HWMEnterpriseDepartmentConstant_h
#define HWMEnterpriseDepartmentConstant_h


typedef NS_ENUM(NSUInteger,HWMEnterpriseDepartmentSelectedStatus){
    HWMEnterpriseDepartmentStatusDisselected = 0,   //未选中
    HWMEnterpriseDepartmentStatusHasSelected ,      //选中
    HWMEnterpriseDepartmentStatusDisselectable     //不可选
};

typedef NS_ENUM(NSUInteger,HWMContactNumberType){
    HWMEnterpriseNumberTypeSip = 0 ,     //sip号码
    HWMEnterpriseNumberTypeMobilePhone , //手机号码
    HWMEnterpriseNumberTypeTelephone     //电话号码
};


typedef NS_ENUM(NSUInteger,HWMEnterpriseSectionType){
    HWMEnterpriseSectionTypeDepartment = 0 , //部门
    HWMEnterpriseSectionTypeContacts         //联系人
};

typedef NS_ENUM(NSUInteger,HWMSelectedContactType){
    HWMSelectedContactTypeEnterprise = 0, //企业联系人
    HWMSelectedContactTypeLocal           //本地联系人（手机通讯录）
};

typedef NS_ENUM(NSUInteger,HWMSelectedContactScene){
    HWMSelectedContactInConf = 0,    //会议中
    HWMSelectedContactBookConf,      //预约会议
    HWMSelectedContactCreateConf     //创建会议
};





#endif /* HWMEnterpriseDepartmentConstant_h */
