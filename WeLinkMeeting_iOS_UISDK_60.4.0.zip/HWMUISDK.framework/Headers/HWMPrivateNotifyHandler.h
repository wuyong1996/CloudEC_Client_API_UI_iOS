//
//  HWMPrivateNotifyHandler.h
//  HWMBaseUI
//
//  Created by x00468765 on 2020/4/28.
//

#import "HWMNotifyHandler.h"

NS_ASSUME_NONNULL_BEGIN

@protocol HWMPrivateNotifyHandler <HWMNotifyHandler>
@optional
/// 语音文件播放完成通知
- (void)onAudioFileEndNotify:(NSUInteger)handle;

@end

NS_ASSUME_NONNULL_END
