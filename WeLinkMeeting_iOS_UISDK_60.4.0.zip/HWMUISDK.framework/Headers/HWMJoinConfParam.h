//
//  HWMJoinConfParam.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMJoinConfParam : NSObject

/// 会议id, 必填字段
@property(nonatomic, strong) NSString *confId;

/// 会议密码, 如果会议有密码，必填，否则不需要
@property(nonatomic, strong) NSString *password;

/// 会议中的昵称
@property(nonatomic, strong) NSString *nickname;

/// 是否打开摄像头.默认打开
@property(nonatomic, assign) BOOL isCameraOn;

/// 是否打开麦克风。默认打开
@property(nonatomic, assign) BOOL isMicOn;


@end

NS_ASSUME_NONNULL_END
