//
//  HWMCreateConfResult.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMCreateConfResult : NSObject
@property (nonatomic, copy) NSString *confId; // 会议id
@property (nonatomic, copy) NSString *confUri; // 会议资源唯一标识
@property (nonatomic, copy) NSString *password; // 会议密码
@property (nonatomic, copy) NSString *accessNumber; // 会议接入码
@end

NS_ASSUME_NONNULL_END
