//
//  HWMStartCallParam.h
//  HWMUISDK
//
//  Created by 融合软终端02 on 2020/3/27.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMStartCallParam : NSObject

/// 呼叫号码 与account 二选一
@property(nonatomic, strong) NSString *number;

/// 呼叫账号 与number 二选一, 如果number有值，默认使用number
@property(nonatomic, strong) NSString *account;

/// 呼叫账号的uuid
//@property(nonatomic, strong) NSString *calleeUuid;

/// 是否发起视频呼叫，默认false
@property(nonatomic, assign) BOOL isVideo;

@end

NS_ASSUME_NONNULL_END
