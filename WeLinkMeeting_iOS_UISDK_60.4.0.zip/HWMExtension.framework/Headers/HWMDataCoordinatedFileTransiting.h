#import "HWMDataTransiting.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMDataCoordinatedFileTransiting : NSObject <HWMDataTransiting>

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithOptionalDirectory:(nullable NSString *)directory NS_DESIGNATED_INITIALIZER;

@property (nonatomic, strong, readonly) NSFileManager *fileManager;

- (nullable NSString *)messagePassingDirectoryPath;

- (nullable NSString *)filePathForIdentifier:(nullable NSString *)identifier;

@property (nonatomic, assign) NSDataWritingOptions additionalFileWritingOptions;

@end

NS_ASSUME_NONNULL_END
