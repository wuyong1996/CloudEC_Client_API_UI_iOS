//
//  HWMBroadcastScreenShare.h
//  HWMConf
//
//  Created by luqiang/00465337 on 2019/12/24.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMExtensionDefine.h"

NS_ASSUME_NONNULL_BEGIN
@protocol HWMBroadcastScreenShareDelegate <NSObject>
- (void)screenShareStateChange:(HWM_EXTENSION_STATE)state;
- (void)screenshareData:(NSDictionary *)data;
@end
API_AVAILABLE(ios(12.0))
@interface HWMBroadcastScreenShare : NSObject
+ (void)startSharingScreenWithExtention:(NSString *)extention;
+ (void)stopSharingScreen;
+ (void)setScreenShareDelegate:(id<HWMBroadcastScreenShareDelegate>)delegate;
@end

NS_ASSUME_NONNULL_END
