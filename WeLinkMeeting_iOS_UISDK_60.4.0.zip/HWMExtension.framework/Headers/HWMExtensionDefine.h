//
//  HWMExtensionDefine.h
//  HWMExtension
//
//  Created by luqiang/00465337 on 2019/12/28.
//  Copyright © 2019年 huawei. All rights reserved.
//

#ifndef HWMExtensionDefine_h
#define HWMExtensionDefine_h

typedef enum : NSUInteger {
    HWM_EXTENSION_STATE_STOP,
    HWM_EXTENSION_STATE_START,
} HWM_EXTENSION_STATE;

#endif /* HWMExtensionDefine_h */
