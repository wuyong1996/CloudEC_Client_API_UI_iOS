//
//  HWMExtensionAppGroup.h
//  HWMExtension
//
//  Created by luqiang/00465337 on 2020/3/20.
//  Copyright © 2020 huawei. All rights reserved.
//

#import <ReplayKit/ReplayKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMExtensionAppGroup : RPBroadcastSampleHandler

+ (void)setAppGroup:(NSString *)appGroup;
+ (NSString *)getAppGroup;

@end

NS_ASSUME_NONNULL_END
