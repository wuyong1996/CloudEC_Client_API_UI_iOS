module.exports = {
    "SEARCH_VIEW_MORE": "Plus",
    "SEARCH_LOADING": "Chargement en cours…",
    "SEARCH_CONTACTS": "Contacts",
    "FILE_NO_EXIST": "Le fichier n'existe pas.",
    "SEARCH_FILE": "Fichiers",
    "SEARCH_VIEW_CORPORATE_ADDRESS_BOOK": "Rechercher dans le répertoire professionnel",
    "SEARCH_ONLINE_GROUP": "Rechercher un groupe de serveurs",
    "SEARCH_FOR_ALL": "Rechercher",
    "SEARCH_FOR_ALL_OR_CALL": "Rechercher un contact ou passer un appel",
    "SEARCH_NO_MORE": "——Pas plus d'infos——",
    "SEARCH_NO_CONTENT": "Aucun résultat trouvé.",
    "NO_CONTACT": "Aucun contact disponible.",
    "NO_RECENT_CALL_LIST": "Aucun historique d'appel",
    "SEARCH_YOU_CAN_SEARCH": "Vous pouvez rechercher"
}