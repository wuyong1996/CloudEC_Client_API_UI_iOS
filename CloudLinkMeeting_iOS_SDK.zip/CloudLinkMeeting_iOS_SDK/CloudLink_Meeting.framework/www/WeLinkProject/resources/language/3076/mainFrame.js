module.exports={
    "MOBILE_CALL_SETTINGS":"呼叫設置",
    "MOBILE_ACCOUNT":"帳號",
    "CONFIRM_QUIT":"確認要退出嗎",
    "MOBILE_SETTINGS":"設定",
    "MOBILE_OPEN_SOURCE_LICENSE":"開源軟件使用說明",
    "MOBILE_BASIC_INFO":"基本",
    "MOBILE_INFOMATION":"個人資訊",
    "MOBILE_GENDER":"性別",
    "MOBILE_DUTIES":"職位",
    "MOBILE_DEPARTMENT":"部門",
    "MOBILE_PHONE":"手機",
    "MOBILE_FAX_NUMBER":"傳真機",
    "COMMON_CONFIRM_UPGRADE_CHECK":"確認檢查有沒有更新版本？",
    "CONFIG_LANGUAGE":"設定語言",
    "SETTING_CONFIRM_CANCELLATION":"確認要登出嗎？",
    "EDIT_SIGNATURE":"編輯簽名",
    "MODIFY_SIGNATURE":"修改簽名",
    "ENTER_SIGNATURE":"請輸入簽名",
    "MENU":"功能表",
    "VIDEO_CALL_TYPE":"影片",
    "AUDIO_CALL_TYPE":"音訊",
    "SETTING_PERSONAL_BASIC":"基本",
    "SETTING_PERSONAL_CONTACT":"聯絡方式",
    "MOBILE_SIGNATURE":"簽名",
    "MOBIL_MYINFO":"我的",
    "MESSAGE_RECIEVE_NOTIFY":"訊息通知",
    "MOBILE_ERROR_REPORT":"錯誤報告",
    "MOBILE_ABOUT":"關於",
    "MULTI_LANGUAGE":"不同語言",
    "MESSAGE_OPEN_SHOCK":"震動",
    "MESSAGE_CALL_COMMING_RING":"啟動來電鈴聲通知",
    "PASSWORD_FORMAT_DESCRIPTION":"密碼要求：",
    "SURE":"確認",
    "COMMON_CONFIRM_SEND_LOG":"確認上載記錄檔案",
    "SOFTWARE_VERSION":"軟件版本",
    "MOBILE_BASIC_SETTINGS":"基本設定",
    "CLOSE_APP_CONFIRM":"關閉程式",
    "MINIMIZE_APP_CONFIRM":"最小化視窗",
    "NO_REMINDER":"往後不再提醒",
    "NO_CALL_RECORD":"暫無通話記錄",
    "PERSONAL_SIGNATURE":"請輸入個人簽名，字數上限為",
    "CALL_MISSED":"未接",
    "MESSAGE_IM_RECIEVE_RING":"接收新消息鈴聲通知",
    "MYCloudLink_INFO":"個人信息",
    "MOBILE_LANGUAGE_SETTINGS":"語言設置",
    "MOBILE_MESSAGE_NOTIFICATION":"消息通知",
    "MOBILE_FONT_SIZE":"字體大小",
    "MOBILE_NOTIFICATION":"通知",
    "MOBILE_POWER_SAVING_MODE":"省電模式",
    "MOBILE_ONLY_SHOW_ONLINE_CONTACTS":"僅顯示在線聯繫人",
    "MOBILE_CLEAR_ALL_CONVERSATIONS":"清除所有對話記錄",
    "MOBILE_PRIVACY_STATEMENT":"隱私聲明",
    "BEGIN_CONFIG_LANGUAGE":"正在更新語言，請稍候⋯"















}