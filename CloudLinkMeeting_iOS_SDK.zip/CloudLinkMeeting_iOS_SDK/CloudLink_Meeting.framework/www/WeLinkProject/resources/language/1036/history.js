module.exports={
    "TARGET_TO_CONTEXT":"Afficher le contexte",
    "HISTORY":"Historique"
}