var SERVERCONFIG = {
  LOGIN_ADDRESS: "bcloudec.huaweicloud.com",
  LOGIN_PORT: "8443"
};