module.exports = {
    "CALLRECORD_CALLING": "Appel",
    "CONVERSATION": "Messages",
    "RECENT_CONTACTS": "Contacts récents",
    "NOTIFICATION_BAR_UNREAD": "[{0} non lu(s)]",
    "COMMON_DELETE": "Supprimer",
    "MULTIDEVICE_PC_LOGINED": "Vous vous êtes connecté au client PC.",
    "BUTTON_ADD": "Ajouter",
    "CONTACT_HAS_NO_USERNAME": "Le contact ne possède pas de nom d'utilisateur.",
    "EVERY_ADVANCE_FROM_COMMUNICATION": "Tout progrès commence par la communication",
    "RECENT_INFO_MEMBER_TITLE": "Membre",
    "RECENT_INFO_IMG_AND_VIDEO_TITLE": "Photos et vidéos",
    "RECENT_INFO_ANNOUNCEMENT_TITLE": "Annonce d'équipe",
    "RECENT_INFO_GROUP_MEMBER_TITLE": "Membre de l'équipe",
    "RECENT_DELETE_CHECK_FILE_TRANSFER": "Transfert du fichier en cours. La suppression de la discussion interrompra le transfert de fichiers. Voulez-vous vraiment la supprimer ?",
    "YOU_HAVE_DISSOLVED_OR_LEFT_THE_GROUP": "Vous avez supprimé ou quitté le groupe."
}