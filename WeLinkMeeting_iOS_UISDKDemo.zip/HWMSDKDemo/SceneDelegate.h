//
//  SceneDelegate.h
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

