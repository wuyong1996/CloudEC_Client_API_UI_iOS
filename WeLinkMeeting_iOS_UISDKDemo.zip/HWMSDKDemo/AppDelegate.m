//
//  AppDelegate.m
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "AppDelegate.h"
#import "NavigationController.h"
#import "FirstViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate
@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    FirstViewController *first = [[FirstViewController alloc] init];
    NavigationController *nav = [[NavigationController alloc] initWithRootViewController:first];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    return YES;
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    if (window.rootViewController) {
        return window.rootViewController.supportedInterfaceOrientations;
    }
    return UIInterfaceOrientationMaskPortrait;
}

@end
