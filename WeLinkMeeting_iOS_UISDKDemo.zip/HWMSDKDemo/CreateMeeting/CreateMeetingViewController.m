//
//  CreateMeetingViewController.m
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "CreateMeetingViewController.h"
#import "MediaTypeSwitchView.h"
#import <HWMUISDK/HWMUISDK.h>
#import "UIUtil.h"
#import <HWMUISDK/HWMPrivateApi.h>

@interface CreateMeetingViewController ()
@property (nonatomic, strong) UITextField *subjectTextField;
@property (nonatomic, assign) BOOL isVideoSelect;
@property (nonatomic, assign) BOOL needPwd;         // 是否需要密码
@property (nonatomic, assign) BOOL needMembers;        // 是否需要与会者
@property (nonatomic, strong) UITextView *memberView;

@property (nonatomic, strong) UISwitch *pwdSwitch;
@property (nonatomic, strong) UISwitch *joinSwitch;

@property (nonatomic, strong) UISwitch *cameraSwitch;
@property (nonatomic, strong) UISwitch *micSwitch;


@property (nonatomic, strong) UIButton * meetingBtn;
@property (nonatomic, strong) NSArray <HWMContactSelectedModel *>*selectedMemebrs;
@end

@implementation CreateMeetingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"创建会议";
}

- (void)setupViews {
    [super setupViews];
    self.subjectTextField = [[UITextField alloc] init];
    [self.view addSubview:self.subjectTextField];
    self.subjectTextField.placeholder = @"会议主题";
    [self.subjectTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(120);
        make.height.mas_equalTo(30);
        make.left.mas_equalTo(50);
        make.right.mas_equalTo(-50);
    }];
    [UIView addBottomLineWithView:self.subjectTextField parentView:self.view];
    
    
    MediaTypeSwitchView * selectView = [[MediaTypeSwitchView alloc] init];
    [self.view addSubview:selectView];
    self.isVideoSelect = NO;
    __weak __typeof(self) weakSelf = self;
    selectView.selectBlcok = ^(SelectType type) {
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.isVideoSelect = type;
    };
    [selectView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.subjectTextField.mas_bottom).mas_offset(20);
        make.left.mas_equalTo(self.subjectTextField);
        make.height.mas_equalTo(50);
        make.right.mas_equalTo(-50);
    }];
    
    
    UILabel * pwdLabel = [self newLabelWithTitle:@"是否需要密码"];
    [self.view addSubview:pwdLabel];
    [pwdLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(selectView.mas_bottom).mas_offset(20);
        make.left.mas_equalTo(selectView);
    }];
    
    self.pwdSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.pwdSwitch];
    self.pwdSwitch.selected = NO;
    [self.pwdSwitch addTarget:self action:@selector(pwdSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.pwdSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(pwdLabel);
        make.right.mas_equalTo(-50);
    }];
    
    UILabel * attendLabel = [self newLabelWithTitle:@"是否需要携带与会者"];
    [self.view addSubview:attendLabel];
    [attendLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(pwdLabel.mas_bottom).mas_offset(20);
        make.left.mas_equalTo(selectView);
    }];
    
    self.joinSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.joinSwitch];
    self.joinSwitch.selected = NO;
    [self.joinSwitch addTarget:self action:@selector(joinSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.joinSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(attendLabel);
        make.right.mas_equalTo(-50);
    }];
    
    UILabel * cameraLabel = [self newLabelWithTitle:@"打开摄像头"];
    [self.view addSubview:cameraLabel];
    [cameraLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.mas_equalTo(attendLabel.mas_bottom).mas_offset(20);
      make.left.mas_equalTo(selectView);
    }];
      
    self.cameraSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.cameraSwitch];
    self.cameraSwitch.on = YES;
    [self.cameraSwitch addTarget:self action:@selector(cameraSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.cameraSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.mas_equalTo(cameraLabel);
      make.right.mas_equalTo(-50);
    }];
    
    UILabel * micLabel = [self newLabelWithTitle:@"打开麦克风"];
    [self.view addSubview:micLabel];
    [micLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.mas_equalTo(cameraLabel.mas_bottom).mas_offset(20);
      make.left.mas_equalTo(selectView);
    }];
      
    self.micSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.micSwitch];
    self.micSwitch.on = YES;
    [self.micSwitch addTarget:self action:@selector(micSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.micSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.mas_equalTo(micLabel);
      make.right.mas_equalTo(-50);
    }];
    
    
    self.memberView = [[UITextView alloc] init];
    self.memberView.textColor = HexColor(0x333333);
    self.memberView.font = [UIFont systemFontOfSize:14];
    self.memberView.hidden = YES;
    [self.view addSubview:self.memberView];
    [self.memberView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(micLabel.mas_bottom).mas_offset(20);
        make.left.right.mas_equalTo(self.subjectTextField);
        make.height.mas_equalTo(80);
    }];
    
    self.meetingBtn = [UIButton newButtonWithTitle:@"创建会议"];
    [self.view addSubview:self.meetingBtn];
    [self.meetingBtn addTarget:self action:@selector(newMeeting) forControlEvents:UIControlEventTouchUpInside];
    [self.meetingBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(micLabel.mas_bottom).mas_offset(50);
        make.left.right.mas_equalTo(self.subjectTextField);
        make.height.mas_equalTo(50);
    }];
}

- (void)cameraSwitchChanged:(UISwitch *)swt{
    
}
- (void)micSwitchChanged:(UISwitch *)swt{
    
}

- (void)pwdSwitchChanged:(UISwitch *)swt {
    self.needPwd = swt.isOn;
}

- (void)joinSwitchChanged:(UISwitch *)swt {
    self.needMembers = swt.isOn;
    self.memberView.hidden = !swt.isOn;
    [self.meetingBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
        if(self.needMembers) {
            make.top.mas_equalTo(self.memberView.mas_bottom).mas_offset(50);
        }
        else {
            make.top.mas_equalTo(self.memberView.mas_top).mas_offset(30);
        }
        make.left.right.mas_equalTo(self.subjectTextField);
        make.height.mas_equalTo(50);
    }];
    if (swt.on) {
        __weak __typeof(self) weakSelf = self;
        __block NSMutableArray *numbers = [NSMutableArray array];
        [self.selectedMemebrs enumerateObjectsUsingBlock:^(HWMContactSelectedModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [numbers addObject:obj.number];
        }];
        [[HWMSdk getPrivateApi] openSelectedContactWithMembers:numbers callback:^(NSArray<HWMContactSelectedModel *> * _Nonnull result, NSError * _Nonnull error) {
            weakSelf.selectedMemebrs = result;
            [weakSelf refreshMemberView];
        }];
    }
    
}

-(void)refreshMemberView{
    __block NSMutableString *memberString = [[NSMutableString alloc] init];
    [self.selectedMemebrs enumerateObjectsUsingBlock:^(HWMContactSelectedModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [memberString appendFormat:@"%@,", obj.name];
    }];
    self.memberView.text = memberString;
}

- (void)newMeeting {
    HWMCreateConfParam *param = [[HWMCreateConfParam alloc] init];
    param.subject = self.subjectTextField.text;
    param.confType = self.isVideoSelect? HWMConfTypeVideoData:HWMConfTypeAudioAndData;
    param.needPassword = self.needPwd;
    param.isCameraOn = self.cameraSwitch.isOn;
    param.isMicOn = self.micSwitch.isOn;
    if (self.needMembers && self.selectedMemebrs) {
        __block NSMutableArray *members = [[NSMutableArray alloc] init];
        [self.selectedMemebrs enumerateObjectsUsingBlock:^(HWMContactSelectedModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            HWMCreateConfMember *member = [[HWMCreateConfMember alloc] init];
            member.accoundId = obj.accountId;
            member.number = obj.number;
            member.name = obj.name;
            member.clientType = HWMClientDeviceTypeDesktop;
            [members addObject:member];
        }];
        param.members = members;
    }
    [self showLoading];
    [[HWMSdk getOpenApi] createConf:param callback:^(NSError * _Nullable error, HWMCreateConfResult * _Nullable result) {
        [self hideLoading];
        if (error) {
            [UIUtil showMessage:error.localizedDescription vc:self];
        }else{
            NSLog(@"创会成功");
        }
    }];
}

- (UILabel *)newLabelWithTitle:(NSString *)title {
    UILabel * label = [[UILabel alloc] init];
    label.text = title;
    label.font = [UIFont systemFontOfSize:16];
    label.textColor = HexColor(0x333333);
    return label;
}

@end
