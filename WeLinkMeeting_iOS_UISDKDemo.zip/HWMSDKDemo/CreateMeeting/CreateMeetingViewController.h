//
//  CreateMeetingViewController.h
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface CreateMeetingViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
