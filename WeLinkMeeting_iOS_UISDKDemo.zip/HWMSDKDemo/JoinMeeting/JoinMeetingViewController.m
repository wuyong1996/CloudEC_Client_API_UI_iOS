//
//  JoinMeetingViewController.m
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "JoinMeetingViewController.h"
#import <HWMUISDK/HWMUISDK.h>
#import "UIUtil.h"

@interface JoinMeetingViewController ()
@property (nonatomic, strong) UITextField *confIdTextField;
@property (nonatomic, strong) UITextField *codeTextField;
@property (nonatomic, strong) UITextField *nickTextField;

@property (nonatomic, strong) UISwitch *cameraSwitch;
@property (nonatomic, strong) UISwitch *micSwitch;

@end

@implementation JoinMeetingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"加入会议";
}

- (void)setupViews {
    [super setupViews];
    self.confIdTextField = [[UITextField alloc] init];
    [self.view addSubview:self.confIdTextField];
    self.confIdTextField.placeholder = @"会议ID";
    [self.confIdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(30);
        make.left.mas_equalTo(50);
        make.right.mas_equalTo(-50);
    }];
    [UIView addBottomLineWithView:self.confIdTextField parentView:self.view];
    
    self.codeTextField = [[UITextField alloc] init];
    [self.view addSubview:self.codeTextField];
    self.codeTextField.placeholder = @"会议密码";
    [self.codeTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.confIdTextField.mas_bottom).mas_offset(25);
        make.height.mas_equalTo(self.confIdTextField);
        make.left.right.mas_equalTo(self.confIdTextField);
    }];
    [UIView addBottomLineWithView:self.codeTextField parentView:self.view];
    
    
    self.nickTextField = [[UITextField alloc] init];
    [self.view addSubview:self.nickTextField];
    self.nickTextField.placeholder = @"用户昵称";
    [self.nickTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.codeTextField.mas_bottom).mas_offset(25);
        make.height.mas_equalTo(self.confIdTextField);
        make.left.right.mas_equalTo(self.confIdTextField);
    }];
    [UIView addBottomLineWithView:self.nickTextField parentView:self.view];

    UILabel * cameraLabel = [self newLabelWithTitle:@"打开摄像头"];
    [self.view addSubview:cameraLabel];
    [cameraLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.mas_equalTo(self.nickTextField.mas_bottom).mas_offset(20);
      make.left.mas_equalTo(self.confIdTextField);
    }];
      
    self.cameraSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.cameraSwitch];
    self.cameraSwitch.on = YES;
    [self.cameraSwitch addTarget:self action:@selector(cameraSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.cameraSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.mas_equalTo(cameraLabel);
      make.right.mas_equalTo(-50);
    }];
    
    UILabel * micLabel = [self newLabelWithTitle:@"打开麦克风"];
    [self.view addSubview:micLabel];
    [micLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.mas_equalTo(cameraLabel.mas_bottom).mas_offset(20);
      make.left.mas_equalTo(self.confIdTextField);
    }];
      
    self.micSwitch = [[UISwitch alloc] init];
    [self.view addSubview:self.micSwitch];
    self.micSwitch.on = YES;
    [self.micSwitch addTarget:self action:@selector(micSwitchChanged:) forControlEvents:(UIControlEventValueChanged)];
    [self.micSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.mas_equalTo(micLabel);
      make.right.mas_equalTo(-50);
    }];
    
    UIButton * joinMeetingBtn = [UIButton newButtonWithTitle:@"加入会议"];
    [self.view addSubview:joinMeetingBtn];
    [joinMeetingBtn addTarget:self action:@selector(joinMeeting) forControlEvents:UIControlEventTouchUpInside];
    [joinMeetingBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(micLabel.mas_bottom).mas_offset(50);
        make.left.right.mas_equalTo(self.confIdTextField);
        make.height.mas_equalTo(50);
    }];
}

- (void)joinMeeting {
    HWMJoinConfParam *param = [[HWMJoinConfParam alloc] init];
    param.confId = self.confIdTextField.text;
    param.password = self.codeTextField.text;
    param.nickname = self.nickTextField.text;
    param.isCameraOn = self.cameraSwitch.isOn;
    param.isMicOn = self.micSwitch.isOn;
    [self showLoading];
    [[HWMSdk getOpenApi] joinConf:param callback:^(NSError * _Nullable error, id  _Nullable result) {
        [self hideLoading];
        if (error) {
            [UIUtil showMessage:error.localizedDescription vc:self];
        }else{
            NSLog(@"入会成功");
        }
    }];
}

- (UILabel *)newLabelWithTitle:(NSString *)title {
    UILabel * label = [[UILabel alloc] init];
    label.text = title;
    label.font = [UIFont systemFontOfSize:16];
    label.textColor = HexColor(0x333333);
    return label;
}

- (void)cameraSwitchChanged:(UISwitch *)swt{
    
}
- (void)micSwitchChanged:(UISwitch *)swt{
    
}
@end
