//
//  UIButton+HWM.m
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "UIButton+HWM.h"

@implementation UIButton (HWM)
+(UIButton *)newButtonWithTitle:(NSString *)title {
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setBackgroundColor:HexColor(0xf3f3f3)];
    [btn setTitleColor:HexColor(0x333333) forState:UIControlStateNormal];
    [btn setTitleColor:HexColor(0x333333) forState:UIControlStateHighlighted];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 5;
    btn.titleLabel.font = [UIFont systemFontOfSize:17];
    return btn;
}
@end
