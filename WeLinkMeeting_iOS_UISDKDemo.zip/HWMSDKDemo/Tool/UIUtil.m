//
//  ShowError.m
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "UIUtil.h"

@implementation UIUtil
+(void)showMessage:(NSString *)message vc:(UIViewController *)vc {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [vc presentViewController:alert animated:true completion:nil];
}
+ (HWMUISDKLaunchType)getLaunchType{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"HWMMeetingSdkLaunchType"] unsignedIntegerValue];
}

+ (void)setLaunchType:(HWMUISDKLaunchType)type{
    [[NSUserDefaults standardUserDefaults] setObject:@(type) forKey:@"HWMMeetingSdkLaunchType"];
}

+ (UIViewController *)findTopPresentViewController:(UIViewController *)vc{
    UIViewController *presentedCtrl = vc.presentedViewController;
    if ([presentedCtrl isKindOfClass:[UIAlertController class]]) {
        return nil;
    }
    while (true){
        if (presentedCtrl.presentedViewController){
            presentedCtrl = presentedCtrl.presentedViewController;
        }else{
            break;
        }
    }
    return presentedCtrl;
}
+ (UIColor *)colorWithHex:(NSUInteger)rgb{
    NSUInteger r = (rgb >> 16) & 0xFF;
    NSUInteger g = (rgb >> 8 ) & 0xFF;
    NSUInteger b = rgb & 0xFF;
    return [UIColor colorWithRed:r / 255.0f green:g / 255.0f blue:b / 255.0f alpha:1.f];
    
}
@end
