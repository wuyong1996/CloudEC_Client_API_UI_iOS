//
//  UIView+HWM.h
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/2.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (HWM)
/// 在视图底部加一个等宽的线
/// @param view 此视图底部添加线
/// @param parentView 父视图
+ (void)addBottomLineWithView:(UIView *)view parentView:(UIView *)parentView;
@end

NS_ASSUME_NONNULL_END
