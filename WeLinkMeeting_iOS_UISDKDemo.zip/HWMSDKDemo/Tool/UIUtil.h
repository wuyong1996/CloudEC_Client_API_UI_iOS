//
//  ShowError.h
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef enum : NSUInteger {
    HWMUISDKLaunchTypePush, // 使用push的方式打开welink会议
    HWMUISDKLaunchTypePresent, // 使用present 的方式打开welink会议
} HWMUISDKLaunchType;

NS_ASSUME_NONNULL_BEGIN

@interface UIUtil : NSObject
+(void)showMessage:(NSString *)message vc:(UIViewController *)vc;
+ (HWMUISDKLaunchType)getLaunchType;

+ (void)setLaunchType:(HWMUISDKLaunchType)type;

+ (UIViewController *)findTopPresentViewController:(UIViewController *)vc;

+ (UIColor *)colorWithHex:(NSUInteger)rgb;
@end

NS_ASSUME_NONNULL_END
