//
//  NavigationController.m
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/4/5.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "NavigationController.h"

@interface NavigationController ()

@end

@implementation NavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    viewController.hidesBottomBarWhenPushed = (self.viewControllers.count > 0);
    [super pushViewController:viewController animated:animated];
}

- (BOOL)shouldAutorotate
{
    if (self.topViewController) {
        return self.topViewController.shouldAutorotate;
    }
    return NO;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    if (self.topViewController) {
       return self.topViewController.preferredInterfaceOrientationForPresentation;
    }
    return UIInterfaceOrientationPortrait;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    if (self.topViewController) {
        return self.topViewController.supportedInterfaceOrientations;
    }
    return UIInterfaceOrientationMaskPortrait;
}

- (void)setNavigationBarHidden:(BOOL)hidden animated:(BOOL)animated {
    [super setNavigationBarHidden:hidden animated:animated];
}

-(void)setNavigationBarHidden:(BOOL)navigationBarHidden {
    [super setNavigationBarHidden:navigationBarHidden];
}

@end
