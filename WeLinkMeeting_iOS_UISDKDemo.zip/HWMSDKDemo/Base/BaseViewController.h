//
//  BaseViewController.h
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UIViewController
@property (nonatomic, strong) UIActivityIndicatorView * activityIndicator;
@property (nonatomic, strong) UIButton *backBtn;

- (void)setupViews;

/// 显示loading
- (void)showLoading;

/// 隐藏loading
- (void)hideLoading;


/// 跳转控制器
/// @param vcString 控制器字符串
- (void)jumpVc:(NSString *)vcString;
@end

NS_ASSUME_NONNULL_END
