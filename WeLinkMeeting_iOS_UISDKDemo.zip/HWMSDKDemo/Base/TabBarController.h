//
//  TabBarController.h
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/4/5.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
