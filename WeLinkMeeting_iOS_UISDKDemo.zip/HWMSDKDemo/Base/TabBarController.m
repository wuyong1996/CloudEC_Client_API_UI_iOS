//
//  TabBarController.m
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/4/5.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "TabBarController.h"

@implementation TabBarController

- (BOOL)shouldAutorotate{
    if (self.selectedViewController) {
        return self.selectedViewController.shouldAutorotate;
    }
    return NO;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    if (self.selectedViewController) {
        return self.selectedViewController.preferredInterfaceOrientationForPresentation;
    }
    return  UIInterfaceOrientationPortrait;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
    if (self.selectedViewController) {
        return self.selectedViewController.supportedInterfaceOrientations;
    }
    return UIInterfaceOrientationMaskPortrait;
}

@end
