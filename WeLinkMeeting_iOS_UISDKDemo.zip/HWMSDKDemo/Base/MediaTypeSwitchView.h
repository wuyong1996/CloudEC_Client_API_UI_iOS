//
//  MediaTypeSwitchView.h
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//
//  选择方式

#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, SelectType) {
    SelectTypeAudio,
    SelectTypeVideo,
    
};
typedef void (^SelectBlcok)(SelectType type);
@interface MediaTypeSwitchView : UIView
@property (nonatomic, copy) SelectBlcok selectBlcok;
@end

NS_ASSUME_NONNULL_END
