



//
//  CallViewController.m
//  HWMSDKDemo
//
//  Created by adminstrator on 2020/4/1.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "CallViewController.h"
#import "MediaTypeSwitchView.h"
#import <HWMUISDK/HWMUISDK.h>
#import "UIUtil.h"

@interface CallViewController ()
@property (nonatomic, strong) UITextField *numberTextField;
@property (nonatomic, strong) UITextField *accountTextField;
@property (nonatomic, assign) BOOL isVideoSelect;

@end

@implementation CallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"发起呼叫";
}

- (void)setupViews {
    [super setupViews];
    self.numberTextField = [[UITextField alloc] init];
    [self.view addSubview:self.numberTextField];
    self.numberTextField.placeholder = @"被呼号码";
    [self.numberTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(100);
        make.height.mas_equalTo(30);
        make.left.mas_equalTo(50);
        make.right.mas_equalTo(-50);
    }];
    [UIView addBottomLineWithView:self.numberTextField parentView:self.view];
    
    self.accountTextField = [[UITextField alloc] init];
    [self.view addSubview:self.accountTextField];
    self.accountTextField.placeholder = @"被呼账号";
    [self.accountTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.numberTextField.mas_bottom).mas_offset(25);
        make.height.mas_equalTo(self.numberTextField);
        make.left.right.mas_equalTo(self.numberTextField);
    }];
    [UIView addBottomLineWithView:self.accountTextField parentView:self.view];
    
    MediaTypeSwitchView * selectView = [[MediaTypeSwitchView alloc] init];
    [self.view addSubview:selectView];
    self.isVideoSelect = NO;
    __weak __typeof(self) weakSelf = self;
    selectView.selectBlcok = ^(SelectType type) {
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.isVideoSelect = type;
    };
    [selectView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.accountTextField.mas_bottom).mas_offset(20);
        make.left.mas_equalTo(self.numberTextField);
        make.height.mas_equalTo(50);
        make.right.mas_equalTo(-50);
    }];
    
    
    UIButton * callBtn = [UIButton newButtonWithTitle:@"发起呼叫"];
    [self.view addSubview:callBtn];
    [callBtn addTarget:self action:@selector(initiateCall) forControlEvents:UIControlEventTouchUpInside];
    [callBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(selectView.mas_bottom).mas_offset(50);
        make.left.right.mas_equalTo(self.accountTextField);
        make.height.mas_equalTo(50);
    }];
    
}


- (void)initiateCall {
    NSLog(@"发起呼叫,%d", self.isVideoSelect);
    HWMStartCallParam *param = [[HWMStartCallParam alloc] init];
    param.isVideo = self.isVideoSelect;
    param.account = self.accountTextField.text;
    param.number = self.numberTextField.text;
    [[HWMSdk getOpenApi] startCall:param callback:^(NSError * _Nullable error, id  _Nullable result) {
        if (error) {
            [UIUtil showMessage:error.localizedDescription vc:self];
        }else{
            NSLog(@"发起呼叫成功");
        }
    }];
}




@end
