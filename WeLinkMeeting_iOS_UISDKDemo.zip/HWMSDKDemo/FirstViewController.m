//
//  FirstViewController.m
//  HWMSDKDemo
//
//  Created by 融合软终端02 on 2020/2/17.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import "FirstViewController.h"
#import "TableViewCell.h"
#import <HWMUISDK/HWMUISDK.h>
#import "UIUtil.h"
// #import <HWMConfUI/HWMConfUI.h>

typedef NS_ENUM(NSInteger, CellType) {
    CellTypeInit,
    CellTypeLogin,
    CellTypeCreateMeeting,
    CellTypeJoinMeeting,
    CellTypeCall,
    CellTypeLogout,
    CellCount,
 };

@interface FirstViewController ()<UITableViewDelegate, UITableViewDataSource, HWMNotifyHandler>
@property (strong, nonatomic)UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupTableView];
    
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[TableViewCell class] forCellReuseIdentifier:@"TableViewCell"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView reloadData];
}

-(void)setupViews{
    [super setupViews];
    self.backBtn.hidden = YES;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"TableViewCell"];
    cell.titleLabel.text = _dataArray[indexPath.row][@"title"];
    [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
    cell.launchTypeSwitch.hidden = YES;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch ([self.dataArray[indexPath.row][@"type"] intValue]) {
        case CellTypeInit: {
            [self initSDK];
        }
            break;
        case CellTypeLogin: {
            [self jumpVc:@"LoginViewController"];
        }
            break;
        case CellTypeCreateMeeting: {
            [self jumpVc:@"CreateMeetingViewController"];
        }
            break;
        case CellTypeJoinMeeting: {
            [self jumpVc:@"JoinMeetingViewController"];
        }
            break;
        case CellTypeCall: {
            [self jumpVc:@"CallViewController"];
        }
            break;
        case CellTypeLogout: {
            [self logout];
        }break;
        default:
            break;
    }
}

/// SDK初始化
- (void)initSDK {
    HWMOpenSDKConfig *config = [[HWMOpenSDKConfig alloc] init];
    config.appId = @"WeLinkMeetingDemo";
    config.globalHandler = self;
    BOOL success = [HWMSdk initWithConfig:config];
    if (success) {
        NSLog(@"初始化成功");
        [UIUtil showMessage:@"初始化成功" vc:self];
    }
}

- (void)onKickedOut:(NSString *)result{
    [UIUtil showMessage:@"您的账号在其他设备登录，您已被迫下线，请重新登录" vc:self];
}

- (void)onCallEnd{
    NSLog(@"on call end");
}

- (void)onConfEnd{
    NSLog(@"on conf end");
}

/// 退出登录
- (void)logout {
    [self showLoading];
    [[HWMSdk getOpenApi] logout:^(NSError * _Nullable error, id  _Nullable result) {
        [self hideLoading];
        NSString *msg = @"登出成功";
        if (error ) {
            msg = [NSString stringWithFormat:@"登出失败:%@", error.localizedDescription];
        }
        [UIUtil showMessage:msg vc:self];
    }];
}

-(NSArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = @[
                       @{@"title":@"初始化", @"type":@(CellTypeInit)},
                       @{@"title":@"登录", @"type":@(CellTypeLogin)},
                       @{@"title":@"创建会议", @"type":@(CellTypeCreateMeeting)},
                       @{@"title":@"加入会议", @"type":@(CellTypeJoinMeeting)},
                       @{@"title":@"呼叫", @"type":@(CellTypeCall)},
                       @{@"title":@"登出", @"type":@(CellTypeLogout)},
        ];
    }
    return _dataArray;
    
}

@end
