//
//  SampleHandler.h
//  ScreenShareExtension
//
//  Created by LL on 2020/4/6.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
