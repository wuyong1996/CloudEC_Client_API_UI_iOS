//
//  BroadcastSetupViewController.h
//  ScreenShareExtensionSetupUI
//
//  Created by LL on 2020/4/6.
//  Copyright © 2020 HuaWei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ReplayKit/ReplayKit.h>

@interface BroadcastSetupViewController : UIViewController

@end
