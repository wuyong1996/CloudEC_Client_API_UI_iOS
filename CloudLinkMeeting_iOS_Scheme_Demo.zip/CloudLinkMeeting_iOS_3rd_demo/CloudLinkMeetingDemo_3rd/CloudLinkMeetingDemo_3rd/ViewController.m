//
//  ViewController.m
//  CloudLinkMeetingDemo_3rd
//
//  Created by cloudlink on 2019/4/3.
//  Copyright © 2019年 cloudlink. All rights reserved.
//

#import "ViewController.h"

#define START_Y 30
#define START_X 5
#define X_SEP 5
#define TEXT_FIELD_WIDTH (([UIScreen mainScreen].bounds.size.width - 15)/2)
#define LBL_WIDTH 80
#define LBL_HEIGHT 40
#define SWITCH_WIDTH (TEXT_FIELD_WIDTH - LBL_WIDTH)
#define SWITCH_HEIGHT 40
#define TEXT_FIELD_HEIGHT 40
#define FIELD_H_SEP   10

#define CLOUDLINKMEETING_LAUNCH_URL @"cloudlink://welinksoftclient/h5page?page=launch"
#define CLOUDLINKMEETING_JOIN_CONF_URL @"cloudlink://welinksoftclient/h5page?page=joinConfByLink&server_url=%@&port=%@&conf_id=%@&enter_code=%@&name=%@&open_mic=%@&open_camera=%@"

@interface ViewController ()
@property (nonatomic, strong) UIButton *launchBtn;
@property (nonatomic, strong) UIButton *joinConfWithoutLoginBtn;
@property (nonatomic, strong) UITextField *serverUrlTextField;
@property (nonatomic, strong) UITextField *serverPortTextField;
@property (nonatomic, strong) UITextField *confIDTextField;
@property (nonatomic, strong) UITextField *enterCodeTextField;
@property (nonatomic, strong) UITextField *nameTextField;
@property (nonatomic, strong) UILabel *micLbl;
@property (nonatomic, strong) UISwitch *micSwitch;
@property (nonatomic, strong) UILabel *cameraLbl;
@property (nonatomic, strong) UISwitch *cameraSwitch;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.launchBtn];
    [self.view addSubview:self.serverUrlTextField];
    [self.view addSubview:self.serverPortTextField];
    [self.view addSubview:self.confIDTextField];
    [self.view addSubview:self.enterCodeTextField];
    [self.view addSubview:self.nameTextField];
    [self.view addSubview:self.micLbl];
    [self.view addSubview:self.micSwitch];
    [self.view addSubview:self.cameraLbl];
    [self.view addSubview:self.cameraSwitch];
    [self.view addSubview:self.joinConfWithoutLoginBtn];
}

- (UIButton *)launchBtn {
    if (nil == _launchBtn) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _launchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _launchBtn.backgroundColor = [UIColor redColor];
        [_launchBtn setTitle:@"launch" forState:UIControlStateNormal];
        _launchBtn.frame = CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                     START_Y,
                                     TEXT_FIELD_WIDTH,
                                     TEXT_FIELD_HEIGHT);
        [_launchBtn addTarget:self action:@selector(launchCloudLinkMeeting:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _launchBtn;
}

- (UITextField *)serverUrlTextField {
    if (nil == _serverUrlTextField) {
        _serverUrlTextField = [[UITextField alloc] initWithFrame:CGRectMake(START_X,
                                                                            START_Y + FIELD_H_SEP + TEXT_FIELD_HEIGHT,
                                                                            TEXT_FIELD_WIDTH,
                                                                            TEXT_FIELD_HEIGHT)];
        _serverUrlTextField.borderStyle = UITextBorderStyleLine;
        _serverUrlTextField.text = @"bcloudec.huaweicloud.com";
        _serverUrlTextField.placeholder = @"server_url";
    }
    return _serverUrlTextField;
}

- (UITextField *)serverPortTextField {
    if (nil == _serverPortTextField) {
        _serverPortTextField = [[UITextField alloc] initWithFrame:CGRectMake(START_X + X_SEP + TEXT_FIELD_WIDTH,
                                                                            START_Y + FIELD_H_SEP + TEXT_FIELD_HEIGHT,
                                                                            TEXT_FIELD_WIDTH,
                                                                            TEXT_FIELD_HEIGHT)];
        _serverPortTextField.borderStyle = UITextBorderStyleLine;
        _serverPortTextField.text = @"8443";
        _serverPortTextField.placeholder = @"port";
    }
    return _serverPortTextField;
}

- (UITextField *)confIDTextField {
    if (nil == _confIDTextField) {
        _confIDTextField = [[UITextField alloc] initWithFrame:CGRectMake(START_X,
                                                                             START_Y + 2 * FIELD_H_SEP + 2 *TEXT_FIELD_HEIGHT,
                                                                             TEXT_FIELD_WIDTH,
                                                                             TEXT_FIELD_HEIGHT)];
        _confIDTextField.borderStyle = UITextBorderStyleLine;
        _confIDTextField.text = @"";
        _confIDTextField.placeholder = @"conf_id";
    }
    return _confIDTextField;
}

- (UITextField *)enterCodeTextField {
    if (nil == _enterCodeTextField) {
        _enterCodeTextField = [[UITextField alloc] initWithFrame:CGRectMake(START_X + X_SEP + TEXT_FIELD_WIDTH,
                                                                         START_Y + 2 * FIELD_H_SEP + 2 *TEXT_FIELD_HEIGHT,
                                                                         TEXT_FIELD_WIDTH,
                                                                         TEXT_FIELD_HEIGHT)];
        _enterCodeTextField.borderStyle = UITextBorderStyleLine;
        _enterCodeTextField.text = @"";
        _enterCodeTextField.placeholder = @"enter_code(可选)";
    }
    return _enterCodeTextField;
}

- (UITextField *)nameTextField {
    if (nil == _nameTextField) {
        _nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(START_X,
                                                                            START_Y + 3 * FIELD_H_SEP + 3 *TEXT_FIELD_HEIGHT,
                                                                            TEXT_FIELD_WIDTH,
                                                                            TEXT_FIELD_HEIGHT)];
        _nameTextField.borderStyle = UITextBorderStyleLine;
        _nameTextField.text = @"测试";
        _nameTextField.placeholder = @"name";
    }
    return _nameTextField;
}

- (UILabel *)micLbl {
    if (nil == _micLbl) {
        _micLbl = [[UILabel alloc] initWithFrame:CGRectMake(START_X + X_SEP + TEXT_FIELD_WIDTH,
                                                                  START_Y + 3 * FIELD_H_SEP + 3 *TEXT_FIELD_HEIGHT,
                                                                  LBL_WIDTH,
                                                                  LBL_HEIGHT)];
         _micLbl.textAlignment = NSTextAlignmentRight;
        _micLbl.text = @"mic";
    }
    return _micLbl;
}



- (UISwitch *)micSwitch {
    if (nil == _micSwitch) {
        _micSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(START_X + X_SEP + TEXT_FIELD_WIDTH + LBL_WIDTH,
                                                                      START_Y + 3 * FIELD_H_SEP + 3 *TEXT_FIELD_HEIGHT,
                                                                      SWITCH_WIDTH,
                                                                      SWITCH_HEIGHT)];
    }
    return _micSwitch;
}

- (UILabel *)cameraLbl {
    if (nil == _cameraLbl) {
        _cameraLbl = [[UILabel alloc] initWithFrame:CGRectMake(START_X,
                                                               START_Y + 4 * FIELD_H_SEP + 4 *TEXT_FIELD_HEIGHT,
                                                               LBL_WIDTH,
                                                               LBL_HEIGHT)];
        _cameraLbl.textAlignment = NSTextAlignmentRight;
        _cameraLbl.text = @"camera";
    }
    return _cameraLbl;
}

- (UISwitch *)cameraSwitch {
    if (nil == _cameraSwitch) {
        _cameraSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(START_X + LBL_WIDTH,
                                                                START_Y + 4 * FIELD_H_SEP + 4 *TEXT_FIELD_HEIGHT,
                                                                TEXT_FIELD_WIDTH,
                                                                TEXT_FIELD_HEIGHT)];
    }
    return _cameraSwitch;
}

- (UIButton *)joinConfWithoutLoginBtn {
    if (nil == _joinConfWithoutLoginBtn) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _joinConfWithoutLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _joinConfWithoutLoginBtn.backgroundColor = [UIColor redColor];
        [_joinConfWithoutLoginBtn setTitle:@"joinConf" forState:UIControlStateNormal];
        _joinConfWithoutLoginBtn.frame = CGRectMake((width - TEXT_FIELD_WIDTH) / 2,
                                      START_Y + 5 * FIELD_H_SEP + 5 *TEXT_FIELD_HEIGHT,
                                      TEXT_FIELD_WIDTH,
                                      TEXT_FIELD_HEIGHT);
        [_joinConfWithoutLoginBtn addTarget:self action:@selector(joinConfWithoutLogin:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _joinConfWithoutLoginBtn;
}

- (void)launchCloudLinkMeeting:(id)sender {
    NSURL *launchUrl = [NSURL URLWithString:CLOUDLINKMEETING_LAUNCH_URL];
    if (![[UIApplication sharedApplication] canOpenURL:launchUrl]) {
        [self showInstallAlert];
        return;
    }
    if (@available(iOS 10.0, *)) {
        [[UIApplication sharedApplication] openURL:launchUrl options:@{} completionHandler:^(BOOL success) {
            [self printOpenUrlResult:success];
        }];
    } else {
        // Fallback on earlier versions
        BOOL isSuccess = [[UIApplication sharedApplication] openURL:launchUrl];
        [self printOpenUrlResult:isSuccess];
    }
}

- (void)joinConfWithoutLogin:(id)sender {
    NSString *server_url = [self urlStringPrepare:self.serverUrlTextField.text];
    NSString *port = [self urlStringPrepare:self.serverPortTextField.text];
    NSString *confId = [self urlStringPrepare:self.confIDTextField.text];
    NSString *enter_code = [self urlStringPrepare:self.enterCodeTextField.text];
    NSString *name = [self urlStringPrepare:self.nameTextField.text];
    NSString *open_mic = self.micSwitch.isOn ? @"true" : @"false";
    NSString *open_camera = self.cameraSwitch.isOn ? @"true" : @"false";
    NSString *joinConfString = [NSString stringWithFormat:CLOUDLINKMEETING_JOIN_CONF_URL, server_url, port, confId, enter_code, name, open_mic, open_camera];
    NSURL *joinConfUrl = [NSURL URLWithString:joinConfString];
    if (![[UIApplication sharedApplication] canOpenURL:joinConfUrl]) {
        [self showInstallAlert];
        return;
    }
    if (@available(iOS 10.0, *)) {
        [[UIApplication sharedApplication] openURL:joinConfUrl options:@{} completionHandler:^(BOOL success) {
            [self printOpenUrlResult:success];
        }];
    } else {
        BOOL isSuccess = [[UIApplication sharedApplication] openURL:joinConfUrl];
        [self printOpenUrlResult:isSuccess];
    }
}

//对原始字符串进行转码处理以用于生成url
- (NSString *)urlStringPrepare:(NSString *)string {
    NSString *urlString = [self emptyStringIfNil:string];
    if (urlString.length > 0) {
        urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLPathAllowedCharacterSet];
    }
    return urlString;
}


- (NSString *)emptyStringIfNil:(NSString *)string {
    if (nil == string) {
        return @"";
    }
    return string;
}

- (void)showInstallAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"警告" message:@"未安装CloudLinkMeeting应用" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)printOpenUrlResult:(BOOL)isSuccess {
    if (isSuccess) {
        NSLog(@"openurl success");
    }
    else {
        NSLog(@"openurl failed");
    }
}



@end
