//
//  CLMDemoViewController.m
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/7/15.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface CLMDemoViewController ()

@end

@implementation CLMDemoViewController

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return  UIInterfaceOrientationMaskPortrait;
}

@end
