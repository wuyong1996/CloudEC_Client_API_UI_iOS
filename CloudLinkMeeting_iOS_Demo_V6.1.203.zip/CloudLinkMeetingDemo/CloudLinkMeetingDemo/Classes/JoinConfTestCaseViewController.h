//
//  JoinConfTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/3/14.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface JoinConfTestCaseViewController : CLMDemoViewController

@end
