//
//  CallTestCaseViewController.h
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/5/29.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface CallTestCaseViewController : CLMDemoViewController

@end

