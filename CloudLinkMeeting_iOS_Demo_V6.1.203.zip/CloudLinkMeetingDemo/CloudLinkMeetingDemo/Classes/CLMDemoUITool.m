//
//  CLMDemoUITool.m
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/7/31.
//  Copyright © 2019 huawei. All rights reserved.
//

#import "CLMDemoUITool.h"

@implementation CLMDemoUITool

+ (void)showAlertControllerWithNavigationControler:(UINavigationController *)navigationController
                                             error:(NSError *)error
                                           apiName:(NSString *)apiName {
    if (nil == apiName || 0 == apiName || nil == navigationController) {
        return;
    }
    NSString *message = (nil == error ? @"success" : [NSString stringWithFormat:@"failed:%@", error]);
    NSString *title = [apiName stringByAppendingString:@" result:"];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:action];
    [navigationController presentViewController:alert animated:YES completion:nil];
}

+ (UIActivityIndicatorView *)activityIndicatorViewWithFrame:(CGRect)frame
                                                      style:(UIActivityIndicatorViewStyle) activityIndicatorViewStyle
                                                      color:(UIColor *)color
{
    UIActivityIndicatorView *activeView = [[UIActivityIndicatorView alloc] initWithFrame:frame];
    activeView.activityIndicatorViewStyle = activityIndicatorViewStyle;
    activeView.color = color;
    return activeView;
}

@end
