//
//  ViewController.h
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/2/22.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import "CLMDemoViewController.h"

@interface ViewController : CLMDemoViewController


@end

