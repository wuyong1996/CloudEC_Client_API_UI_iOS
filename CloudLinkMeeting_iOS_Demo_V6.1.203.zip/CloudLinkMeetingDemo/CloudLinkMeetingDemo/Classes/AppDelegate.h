//
//  AppDelegate.h
//  CloudLinkMeetingDemo
//
//  Created by cloudlink on 2019/2/22.
//  Copyright © 2019年 huawei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

