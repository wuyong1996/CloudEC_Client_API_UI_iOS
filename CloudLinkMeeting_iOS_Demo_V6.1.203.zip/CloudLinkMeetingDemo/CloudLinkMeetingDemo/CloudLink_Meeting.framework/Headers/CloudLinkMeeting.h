//
//  CloudLink_Meeting.h
//  CloudLink Meeting
//
//  Created by zhangjianfang on 2019/2/21.
//

#import <Foundation/Foundation.h>
#import "CloudLinkMeetingInfo.h"

//! Project version number for CloudLink_Meeting.
FOUNDATION_EXPORT double CloudLink_MeetingVersionNumber;

//! Project version string for CloudLink_Meeting.
FOUNDATION_EXPORT const unsigned char CloudLink_MeetingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CloudLink_Meeting/PublicHeader.h>

NS_ASSUME_NONNULL_BEGIN
@protocol CloudLinkMeetingNotifyDelegate <NSObject>

@optional

/**
 用户被踢通知
 
 @param code 被踢原因码
 @param kickedMsg 被踢原因描述
 */
- (void)clmUserWasKickedOutWithCode:(NSInteger)code msg:(NSString *)kickedMsg;

@end

typedef void(^clmActionCompletionBlock)(NSError * _Nullable error);

@interface CloudLinkMeeting : NSObject
@property (nonatomic, weak, nullable) id<CloudLinkMeetingNotifyDelegate> notifyDelegate;

@property (nonatomic, copy) NSString *screenShareGroupId;//屏幕共享extension的groupid

/**
 单例接口

 @return CloudLinkMeeting单例对象
 */
+ (instancetype)sharedInstance;


/**
 带配置初始化接口(默认初始化方法)

 @param initParam 初始化参数
 @param completionBlock 完成回调
 */
- (void)clm_init:(clmInitParam *)initParam
 completionBlock:(clmActionCompletionBlock)completionBlock;


/**
 登录接口(需要先初始化才能调用)

 @param loginParam 登录参数
 @param completionBlock 完成回调
 */
- (void)clm_login:(clmLoginParam *)loginParam
  completionBlock:(clmActionCompletionBlock)completionBlock;

/**
 SSO登录接口(需要先初始化才能调用)
 
 @param loginParam 登录参数
 @param completionBlock 完成回调
 */

- (void)clm_ssoLogin:(clmSsoLoginParam *)loginParam
     completionBlock:(clmActionCompletionBlock)completionBlock;

/**
 注销接口(已登录账号可以进行注销)

 @param completionBlock 完成回调
 */
- (void)clm_logoutWithCompletionBlock:(clmActionCompletionBlock)completionBlock;

/**
 发起呼叫接口(需要先初始化才能调用)

 @param callParam 呼叫参数
 @param completionBlock 完成回调
 */
- (void)clm_call:(clmCallParam *)callParam
 completionBlock:(clmActionCompletionBlock)completionBlock;


/**
 创建会议接口(需要先初始化登录才能调用)

 @param createParam 创会参数
 @param completionBlock 完成回调
 */
- (void)clm_createMeeting:(clmCreateMeetingParam *)createParam
          completionBlock:(clmActionCompletionBlock)completionBlock;


/**
 创建会议接口(带多个与会者)(需要先初始化才能调用)

 @param createParam 创会参数
 @param participants 会议与会者(除了自己之外)
 @param completionBlock 完成回调
 */
- (void)clm_createMeeting:(clmCreateMeetingParam *)createParam
         withParticipants:(NSArray <clmMeetingParticipantParam *> *)participants
          completionBlock:(clmActionCompletionBlock)completionBlock;


/**
 使用会议ID入会接口(需要先初始化才能调用)

 @param joinParam 加入会议参数
 @param completionBlock 完成回调
 */
- (void)clm_joinMeetingById:(clmJoinMeetingByIdParam *)joinParam
            completionBlock:(clmActionCompletionBlock)completionBlock;

@end
NS_ASSUME_NONNULL_END

